const mongoose=require("mongoose")

const labReportSchema=new mongoose.Schema({



})
const LABREPORT=new mongoose.model("labReportSchema",labReportSchema)
module.exports=LABREPORTS;